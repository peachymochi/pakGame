Hello, welcome to my snake game. In order to be able to run and play this game, 
you must have pygame.
If you do not have pygame, you can go to: https://www.pygame.org/wiki/GettingStarted
and install the program.